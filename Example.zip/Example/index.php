<?php

$display_form = ($_SERVER['REQUEST_METHOD'] == 'GET')? true : false;
$errors = [];

if($display_form != true) {
    $name = $_POST['name'];
    $email = $_POST['email'];
    $website = $_POST['website'];
    $comment = $_POST['comment'];
    $gender = isset($_POST['gender'])? $_POST['gender'] : '';
    $status = $_POST['status'];
    $law = isset($_POST['law'])? $_POST['law'] : '';


    if(empty($name)) {
        $errors[] = 'Please enter a name.';
    } elseif (strlen($name) < 3) {
        $errors[] = 'The name is less than 3 chars.';
    }

    if(empty($email)) {
        $errors[] = 'Please enter a email.';
    } elseif(! filter_var($email, FILTER_VALIDATE_EMAIL)) {
        $errors[] = 'Email is invalid.';
    }

    if(empty($website)) {
        $errors[] = 'Please enter a website.';
    } elseif(! filter_var('http://' . $website, FILTER_VALIDATE_URL)) {
        $errors[] = 'Website is invalid.';
    }

    if(empty($comment)) {
        $errors[] = 'Please enter comment.';
    } elseif(strlen($comment) < 5) {
        $errors[] = 'The comment is less than 5 chars.';
    }

    if(! in_array($status, ['important', 'medium', 'low'])) {
        $errors[] = 'Status is invalid.';
    }

    if(! in_array($gender, ['male', 'female'])) {
        $errors[] = 'Gender is invalid.';
    }

    if($law == '') {
        $errors[] = 'Please check law.';
    }

    if(count($errors) > 0) {
        $display_form = true;
    }
}


?>

<html>
<head>
    <title>Form</title>
    <link href="./css/style.css" rel="stylesheet">
</head>
<body>

<?php if($display_form == true): ?>
    <main>
        <h2 class="center">Comment form</h2>
        <?php if(count($errors) > 0): ?>
            <div id="error">
                <ul>
                    <?php foreach($errors as $error): ?>
                        <li><span class="error"><?= $error ?></span></li>
                    <?php endforeach ?>
                </ul>
            </div>
        <?php endif ?>
        <form method="post">
            <div class="form-control">
                <label for="name">Name:</label>
                <input type="text" id="name" name="name" value="<?= isset($name)? $name : '' ?>">
            </div>
            <div class="form-control">
                <label for="email">E-mail:</label>
                <input type="text" id="email" name="email" value="<?= isset($email)? $email : '' ?>">
            </div>
            <div class="form-control">
                <label for="website">Website:</label>
                <input type="text" id="website" name="website" value="<?= isset($website)? $website : '' ?>">
            </div>
            <div class="form-control">
                <label for="comment">Comment:</label>
                <textarea name="comment" id="comment" rows="5" cols="40"><?= isset($comment)? $comment : '' ?></textarea>
            </div>
            <div class="form-control">
                <label for="status">Status:</label>
                <select name="status" id="status">
                    <option>Please select status</option>
                    <option value="important" <?= (isset($status) and $status == 'important')? 'selected' : '' ?>>Important</option>
                    <option value="medium" <?= (isset($status) and $status == 'medium')? 'selected' : '' ?>>medium</option>
                    <option value="low" <?= (isset($status) and $status == 'low')? 'selected' : '' ?>>low</option>
                </select>
            </div>
            <div class="form-control">
                <label for="gender">Gender:</label>
                <input type="radio" name="gender" <?= (isset($gender) and $gender == 'female')? 'checked' : '' ?> value="female"> Female
                <input type="radio" name="gender" <?= (isset($gender) and $gender == 'male')? 'checked' : '' ?> value="male"> Male
            </div>
            <div class="form-control">
                <input type="checkbox" id="law" <?= (isset($law) and $law == 'law')? 'checked' : '' ?> name="law" value="law"> I accept
            </div>
            <div class="form-control center">
                <input type="submit" value="submit">
            </div>
        </form>
    </main>
<?php else: ?>
    <section>
        <table>
            <thead>
            <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Website</th>
                <th>Gender</th>
                <th>Status</th>
            </tr>
            </thead>
            <tbody>
            <tr>
                <td><?= $name ?></td>
                <td><?= $email ?></td>
                <td><?= $website ?></td>
                <td><?= $gender ?></td>
                <td><?= $status ?></td>
            </tr>
            </tbody>
            <thead>
                <tr>
                    <th colspan="5">Comment</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td colspan="5"><?= $comment ?></td>
                </tr>
            </tbody>
        </table>
    </section>
<?php endif ?>

</body>
</html>